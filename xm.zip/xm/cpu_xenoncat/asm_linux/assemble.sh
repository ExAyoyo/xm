./fasm -m 1280000 equihash_avx1.asm
./fasm -m 1280000 equihash_avx2.asm
